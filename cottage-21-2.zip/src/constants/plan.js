export const PlanStatus = {
  DRAFT: "DRAFT",
  ACTIVE: "ACTIVE",
  INACTIVE: "INACTIVE",
};

export const PlanInterval = {
  WEEKLY: "WEEKLY",
  MONTHLY: "MONTHLY",
};
