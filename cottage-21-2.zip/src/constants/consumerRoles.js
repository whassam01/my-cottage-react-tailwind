export const ConsumerRoles = {
  GUEST_CONSUMER: "GUEST_CONSUMER",
};
