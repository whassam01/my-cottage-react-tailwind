export const InvoiceStatus = {
  DRAFT: "DRAFT",
  OPEN: "OPEN",
  PAID: "PAID",
  UNCOLLECTIBLE: "UNCOLLECTIBLE",
  VOID: "VOID",
};
