export const BYTES_TO_MB = 1024 * 1024;
export const MAX_IMAGE_SIZE_MB = 10;
