export const TransportationType = {
  PICK_UP: "PICK_UP",
  DELIVERY: "DELIVERY",
};
