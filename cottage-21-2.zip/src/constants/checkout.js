export const CheckoutType = {
  ORDER: "ORDER",
  SUBSCRIPTION: "SUBSCRIPTION",
};
