export const MAX_OFFER_QUANTITY = 100;

export const OfferStatus = {
  DRAFT: "DRAFT",
  ACTIVE: "ACTIVE",
  INACTIVE: "INACTIVE",
};
