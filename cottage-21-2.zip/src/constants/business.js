export const BusinessStatus = {
  DRAFT: "DRAFT",
  ACTIVE: "ACTIVE",
  INACTIVE: "INACTIVE",
};

export const BusinessTabs = {
  PRODUCT: "Products",
  SUBSCRIPTION: "Subscriptions",
};
