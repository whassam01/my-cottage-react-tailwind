export const StateOrProvince = ["FL", "WA", "TX", "CA"];

export const CountryCode = ["US"];
