export const PaymentStatus = {
  SUCCEEDED: "SUCCEEDED",
  PENDING: "PENDING",
  FAILED: "FAILED",
};
