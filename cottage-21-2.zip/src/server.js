const prerender = require("prerender");
const server = prerender();
server.start();
