export const TaxRateActionType = {
  GET_TAX_RATE_REQUESTED: 'GET_TAX_RATE_REQUESTED',
  GET_TAX_RATE_SUCCESS: 'GET_TAX_RATE_SUCCESS',
  GET_TAX_RATE_ERROR: 'GET_TAX_RATE_ERROR',
};

export const TaxRateKeys = {
  TaxRate: 'taxRate',
};
