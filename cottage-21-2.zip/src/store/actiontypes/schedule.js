export const ScheduleActionType = {
  GET_SCHEDULES_REQUESTED: 'GET_SCHEDULES_REQUESTED',
  GET_SCHEDULES_SUCCESS: 'GET_SCHEDULES_SUCCESS',
  GET_SCHEDULES_ERROR: 'GET_SCHEDULES_ERROR',
};

export const ScheduleKeys = {
  Schedules: 'schedules',
};
