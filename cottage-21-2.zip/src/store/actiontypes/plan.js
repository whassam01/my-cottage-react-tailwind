export const PlanActionType = {
  GET_PLANS_REQUESTED: 'GET_PLANS_REQUESTED',
  GET_PLANS_SUCCESS: 'GET_PLANS_SUCCESS',
  GET_PLANS_ERROR: 'GET_PLANS_ERROR',
};

export const PlanKeys = {
  Plan: 'plan',
};
