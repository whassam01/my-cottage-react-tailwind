export const OfferActionType = {
  GET_OFFERS_REQUESTED: 'GET_OFFERS_REQUESTED',
  GET_OFFERS_SUCCESS: 'GET_OFFERS_SUCCESS',
  GET_OFFERS_ERROR: 'GET_OFFERS_ERROR',
};

export const OfferKeys = {
  Offer: 'offer',
};
